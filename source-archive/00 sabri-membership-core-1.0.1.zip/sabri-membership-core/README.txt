Sabri Membership Core 1.0.1
================================

Institutional membership, identity, verification, security, profiles, clinic
identity, permissions and organized knowledge ownership for Sabri Homeopathy.

IMPORTANT INSTALLATION ORDER
----------------------------
1. Keep a verified UpdraftPlus/Hostinger backup.
2. Test this ZIP on the Hostinger staging site first.
3. Upload the ZIP through Plugins > Add Plugin > Upload Plugin.
4. Choose Replace current with uploaded when updating version 0.4.0.
5. Activate the plugin. Existing Sabri member metadata is migrated without
   intentionally deleting existing users, approvals or knowledge entries.
6. Open Sabri Membership > Verification Queue and test one new account.
7. Confirm email delivery and configure a mobile OTP provider through the
   `smc_send_phone_otp` filter. Until a provider is connected, an authorized
   institutional reviewer must verify the mobile number before approval.
8. Flush LiteSpeed and Hostinger CDN caches after final acceptance.

PRODUCTION ENCRYPTION KEY
-------------------------
For a production-independent document key, add a long random constant to
wp-config.php before accepting new version-1 registrations:

define( 'SMC_MASTER_KEY', 'replace-with-a-long-random-secret-kept-in-backups' );

Do not change or lose this key after documents are encrypted. Changing it
without a controlled migration makes encrypted documents unreadable.

ACCOUNT AND VERIFICATION
------------------------
- Minimum age 15 using a date-of-birth calendar.
- Identity front, identity back/secondary page, and clear profile photograph.
- Role-specific doctor and clinic/institution evidence.
- Email code, mandatory Google Authenticator TOTP, recovery codes.
- Mobile must be verified before institutional approval.
- Versioned institutional states, reviewer notes and audit records.
- Approval does not reset on ordinary login.

PUBLISHING POLICY
-----------------
- Sabri-managed non-doctors cannot publish posts.
- Doctors may submit knowledge and posts for review.
- Official Founder and institutionally trusted doctors may publish directly.
- Allowed knowledge sections are Homeopathy, Nutrition Science, Pathology and
  Disease Science, Preventive Health, Islamic Spiritual Care, and the organized
  book/research/case/reference sub-sections defined by Sabri Homeopathy.

PAYMENT FOUNDATION
------------------
The database stores plan status, renewal references and the fixed default
10 percent per-patient commission. Actual WooCommerce payment collection,
appointment charging, refunds and doctor payouts remain integration modules.

PRIVACY
-------
- Private evidence is encrypted outside the WordPress Media Library.
- Documents have no public URL and require a reviewer capability plus nonce.
- Public profiles do not expose ID/passport number or full date of birth.
- WordPress personal-data export and erasure callbacks are registered.
- Social, knowledge and future clinical records remain separate security areas.

SHORTCODES
----------
[sabri_register]
[sabri_login]
[sabri_profile]
[sabri_knowledge_archive]
[sabri_security_center]
[sabri_verification_status]

DEFAULT PAGES
-------------
The plugin creates or preserves the matching Sabri pages during activation.

RELEASE SCOPE
-------------
This release provides the approved Membership foundation. Full appointments,
EHR, prescriptions, internal messaging/calls, payment gateways, translation,
social feed, video and mobile applications remain separate modules built on
this foundation.
