<?php
/**
 * Plugin Name: Sabri Membership Core
 * Description: Institutional membership, identity, verification, security, professional profiles, clinic identity and permissions for Sabri Homeopathy.
 * Version: 1.0.1
 * Author: Sabri Homeopathy
 * Requires at least: 6.1
 * Requires PHP: 7.4
 * Text Domain: sabri-membership-core
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'SMC_VERSION', '1.0.1' );
define( 'SMC_DB_VERSION', '1.0.1' );
define( 'SMC_FILE', __FILE__ );
define( 'SMC_PATH', plugin_dir_path( __FILE__ ) );
define( 'SMC_URL', plugin_dir_url( __FILE__ ) );

require_once SMC_PATH . 'includes/functions.php';
require_once SMC_PATH . 'includes/class-smc-installer.php';
require_once SMC_PATH . 'includes/class-smc-security.php';
require_once SMC_PATH . 'includes/class-smc-registration.php';
require_once SMC_PATH . 'includes/class-smc-knowledge.php';
require_once SMC_PATH . 'includes/class-smc-profile.php';
require_once SMC_PATH . 'includes/class-smc-admin.php';

register_activation_hook( SMC_FILE, array( 'SMC_Installer', 'activate' ) );

add_action( 'plugins_loaded', function() {
	SMC_Installer::maybe_upgrade();
	SMC_Security::init();
	SMC_Registration::init();
	SMC_Knowledge::init();
	SMC_Profile::init();
	SMC_Admin::init();
} );

add_action( 'wp_enqueue_scripts', function() {
	if ( ! smc_is_membership_page() ) return;
	wp_enqueue_style( 'smc-modern', SMC_URL . 'assets/smc-modern.css', array(), SMC_VERSION );
	wp_enqueue_script( 'smc-qrcode', SMC_URL . 'assets/qrcode.js', array(), '1.4.4', true );
	wp_enqueue_script( 'smc-modern', SMC_URL . 'assets/smc-modern.js', array( 'smc-qrcode' ), SMC_VERSION, true );
	wp_localize_script( 'smc-modern', 'smcConfig', array(
		'minAge' => 15,
		'doctorRole' => 'sabri_doctor',
		'clinicRole' => 'sabri_clinic',
	) );
} );
