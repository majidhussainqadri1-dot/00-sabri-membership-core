<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMC_Installer {
	public static function activate() {
		self::create_tables();
		self::create_roles();
		self::create_pages();
		self::seed_knowledge();
		self::migrate_legacy();
		self::ensure_founder();
		update_option( 'smc_db_version', SMC_DB_VERSION, false );
		flush_rewrite_rules( false );
	}

	public static function maybe_upgrade() {
		if ( get_option( 'smc_db_version' ) !== SMC_DB_VERSION ) self::activate();
	}

	private static function create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		$c = $wpdb->get_charset_collate();
		$p = $wpdb->prefix;
		$sql = array();
		$sql[] = "CREATE TABLE {$p}smc_member_profiles (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT, user_id bigint(20) unsigned NOT NULL,
			legal_name varchar(190) NOT NULL DEFAULT '', guardian_name varchar(190) NOT NULL DEFAULT '', username_public varchar(100) NOT NULL DEFAULT '',
			phone varchar(40) NOT NULL DEFAULT '', address text NULL, country varchar(100) NOT NULL DEFAULT '', city varchar(100) NOT NULL DEFAULT '', gender varchar(40) NOT NULL DEFAULT '',
			preferred_language varchar(100) NOT NULL DEFAULT 'English', date_of_birth_enc longtext NULL, calculated_age smallint unsigned NOT NULL DEFAULT 0,
			account_type varchar(60) NOT NULL DEFAULT '', bio longtext NULL, profile_visibility varchar(20) NOT NULL DEFAULT 'members',
			created_at datetime NOT NULL, updated_at datetime NOT NULL, PRIMARY KEY (id), UNIQUE KEY user_id (user_id), KEY account_type (account_type), KEY country_city (country,city)
		) $c;";
		$sql[] = "CREATE TABLE {$p}smc_verification_requests (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT, user_id bigint(20) unsigned NOT NULL, verification_type varchar(60) NOT NULL DEFAULT 'identity',
			status varchar(60) NOT NULL DEFAULT 'submitted', assigned_reviewer bigint(20) unsigned NOT NULL DEFAULT 0, reviewer_note longtext NULL,
			submitted_at datetime NULL, decided_at datetime NULL, expires_at datetime NULL, created_at datetime NOT NULL, updated_at datetime NOT NULL,
			PRIMARY KEY (id), KEY user_status (user_id,status), KEY assigned_reviewer (assigned_reviewer)
		) $c;";
		$sql[] = "CREATE TABLE {$p}smc_identity_records (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT, user_id bigint(20) unsigned NOT NULL, document_type varchar(40) NOT NULL,
			document_number_enc longtext NOT NULL, name_match tinyint(1) NOT NULL DEFAULT 0, verified_at datetime NULL, verified_by bigint(20) unsigned NOT NULL DEFAULT 0,
			created_at datetime NOT NULL, updated_at datetime NOT NULL, PRIMARY KEY (id), UNIQUE KEY user_id (user_id)
		) $c;";
		$sql[] = "CREATE TABLE {$p}smc_identity_documents (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT, user_id bigint(20) unsigned NOT NULL, document_key varchar(80) NOT NULL,
			label varchar(190) NOT NULL, stored_name varchar(190) NOT NULL, original_name varchar(190) NOT NULL DEFAULT '', mime_type varchar(80) NOT NULL,
			file_size bigint(20) unsigned NOT NULL DEFAULT 0, issue_date date NULL, expiry_date date NULL, status varchar(30) NOT NULL DEFAULT 'submitted', created_at datetime NOT NULL,
			PRIMARY KEY (id), UNIQUE KEY user_document (user_id,document_key), KEY status (status), KEY expiry_date (expiry_date)
		) $c;";
		$sql[] = "CREATE TABLE {$p}smc_verification_events (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT, request_id bigint(20) unsigned NOT NULL DEFAULT 0, user_id bigint(20) unsigned NOT NULL,
			actor_id bigint(20) unsigned NOT NULL DEFAULT 0, old_status varchar(60) NOT NULL DEFAULT '', new_status varchar(60) NOT NULL DEFAULT '', note longtext NULL,
			created_at datetime NOT NULL, PRIMARY KEY (id), KEY request_id (request_id), KEY user_id (user_id)
		) $c;";
		$sql[] = "CREATE TABLE {$p}smc_professional_credentials (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT, user_id bigint(20) unsigned NOT NULL, qualification text NULL, institution varchar(190) NOT NULL DEFAULT '',
			registration_number varchar(190) NOT NULL DEFAULT '', license_number varchar(190) NOT NULL DEFAULT '', council varchar(190) NOT NULL DEFAULT '',
			license_issue date NULL, license_expiry date NULL, experience_years smallint unsigned NOT NULL DEFAULT 0, specialization text NULL, books_studied longtext NULL,
			consultation_mode varchar(60) NOT NULL DEFAULT '', fee decimal(12,2) NOT NULL DEFAULT 0, currency varchar(12) NOT NULL DEFAULT 'USD', languages text NULL,
			created_at datetime NOT NULL, updated_at datetime NOT NULL, PRIMARY KEY (id), UNIQUE KEY user_id (user_id), KEY license_expiry (license_expiry)
		) $c;";
		$sql[] = "CREATE TABLE {$p}smc_clinics (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT, owner_user_id bigint(20) unsigned NOT NULL, name varchar(190) NOT NULL, address text NULL,
			country varchar(100) NOT NULL DEFAULT '', city varchar(100) NOT NULL DEFAULT '', phone varchar(40) NOT NULL DEFAULT '', whatsapp varchar(40) NOT NULL DEFAULT '',
			hours text NULL, timezone varchar(100) NOT NULL DEFAULT '', status varchar(40) NOT NULL DEFAULT 'pending', created_at datetime NOT NULL, updated_at datetime NOT NULL,
			PRIMARY KEY (id), KEY owner_user_id (owner_user_id), KEY country_city (country,city), KEY status (status)
		) $c;";
		$sql[] = "CREATE TABLE {$p}smc_security_events (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT, user_id bigint(20) unsigned NOT NULL DEFAULT 0, event_type varchar(100) NOT NULL,
			ip_hash char(64) NOT NULL DEFAULT '', user_agent_hash char(64) NOT NULL DEFAULT '', details longtext NULL, created_at datetime NOT NULL,
			PRIMARY KEY (id), KEY user_event (user_id,event_type), KEY created_at (created_at)
		) $c;";
		$sql[] = "CREATE TABLE {$p}smc_consents (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT, user_id bigint(20) unsigned NOT NULL, consent_type varchar(100) NOT NULL, policy_version varchar(30) NOT NULL,
			status varchar(20) NOT NULL DEFAULT 'accepted', ip_hash char(64) NOT NULL DEFAULT '', accepted_at datetime NULL, withdrawn_at datetime NULL,
			PRIMARY KEY (id), KEY user_type (user_id,consent_type), KEY policy_version (policy_version)
		) $c;";
		$sql[] = "CREATE TABLE {$p}smc_subscriptions (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT, user_id bigint(20) unsigned NOT NULL, plan_key varchar(60) NOT NULL DEFAULT 'free_member',
			status varchar(30) NOT NULL DEFAULT 'inactive', starts_at datetime NULL, renews_at datetime NULL, external_order_id bigint(20) unsigned NOT NULL DEFAULT 0,
			commission_rate decimal(5,2) NOT NULL DEFAULT 10.00, created_at datetime NOT NULL, updated_at datetime NOT NULL,
			PRIMARY KEY (id), UNIQUE KEY user_id (user_id), KEY status (status)
		) $c;";
		$sql[] = "CREATE TABLE {$p}smc_audit_log (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT, actor_id bigint(20) unsigned NOT NULL DEFAULT 0, subject_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
			action varchar(120) NOT NULL, object_type varchar(80) NOT NULL DEFAULT '', object_id bigint(20) unsigned NOT NULL DEFAULT 0, details longtext NULL, created_at datetime NOT NULL,
			PRIMARY KEY (id), KEY subject_user_id (subject_user_id), KEY actor_action (actor_id,action), KEY created_at (created_at)
		) $c;";
		foreach ( $sql as $statement ) dbDelta( $statement );
	}

	private static function create_roles() {
		add_role( 'sabri_pending', 'Sabri Pending Member', array( 'read' => false ) );
		foreach ( smc_roles() as $key => $label ) {
			$caps = array( 'read' => true, 'smc_view_own_profile' => true, 'smc_edit_own_profile' => true );
			if ( 'sabri_doctor' === $key ) $caps += array( 'smc_submit_knowledge'=>true, 'edit_posts'=>true, 'upload_files'=>true );
			add_role( $key, $label, $caps );
			$role = get_role( $key );
			if ( $role ) foreach ( $caps as $cap => $grant ) if ( $grant ) $role->add_cap( $cap );
		}
		$special = array(
			'sabri_verified_doctor' => array( 'Sabri Verified Doctor', array( 'read'=>true,'smc_view_own_profile'=>true,'smc_edit_own_profile'=>true,'smc_submit_knowledge'=>true,'edit_posts'=>true,'upload_files'=>true ) ),
			'sabri_verification_reviewer' => array( 'Sabri Verification Reviewer', array( 'read'=>true,'smc_review_verification'=>true,'smc_view_private_documents'=>true ) ),
			'sabri_medical_reviewer' => array( 'Sabri Medical Reviewer', array( 'read'=>true,'edit_posts'=>true,'publish_posts'=>true,'smc_review_knowledge'=>true ) ),
			'sabri_moderator' => array( 'Sabri Moderator', array( 'read'=>true,'moderate_comments'=>true,'smc_moderate_members'=>true ) ),
			'sabri_finance_manager' => array( 'Sabri Finance Manager', array( 'read'=>true,'smc_manage_finance'=>true ) ),
		);
		foreach ( $special as $key => $data ) { add_role( $key, $data[0], $data[1] ); $role=get_role($key); if($role)foreach($data[1] as$cap=>$grant)if($grant)$role->add_cap($cap); }
		$admin = get_role( 'administrator' );
		if ( $admin ) foreach ( array( 'smc_review_verification','smc_view_private_documents','smc_review_knowledge','smc_moderate_members','smc_manage_finance','smc_manage_membership' ) as $cap ) $admin->add_cap( $cap );
	}

	private static function create_pages() {
		$pages = array(
			'Sabri Register' => '[sabri_register]', 'Sabri Login' => '[sabri_login]', 'Sabri Profile' => '[sabri_profile]',
			'Sabri Knowledge Archive' => '[sabri_knowledge_archive]', 'Sabri Security Center' => '[sabri_security_center]',
			'Sabri Verification Status' => '[sabri_verification_status]',
		);
		foreach ( $pages as $title => $content ) {
			$existing = self::page_by_title( $title );
			if ( $existing ) continue;
			wp_insert_post( array( 'post_title'=>$title, 'post_content'=>$content, 'post_status'=>'publish', 'post_type'=>'page' ) );
		}
	}

	private static function page_by_title( $title ) {
		$pages = get_posts( array(
			'post_type'              => 'page',
			'post_status'            => array( 'publish', 'draft', 'pending', 'private' ),
			'title'                  => $title,
			'posts_per_page'         => 1,
			'no_found_rows'          => true,
			'update_post_meta_cache' => false,
			'update_post_term_cache' => false,
		) );

		return ! empty( $pages ) ? $pages[0] : null;
	}

	private static function seed_knowledge() {
		SMC_Knowledge::register();
		foreach ( smc_knowledge_sections() as $slug => $name ) if ( ! term_exists( $slug, 'sabri_knowledge_type' ) ) wp_insert_term( $name, 'sabri_knowledge_type', array( 'slug'=>$slug ) );
	}

	private static function migrate_legacy() {
		global $wpdb;
		$users = get_users( array( 'meta_key'=>'_smc_requested_role', 'fields'=>array( 'ID','display_name','user_login' ) ) );
		foreach ( $users as $user ) {
			$now = current_time( 'mysql', true );
			if ( ! smc_get_profile( $user->ID ) ) $wpdb->insert( $wpdb->prefix . 'smc_member_profiles', array(
				'user_id'=>$user->ID, 'legal_name'=>$user->display_name, 'username_public'=>$user->user_login,
				'phone'=>get_user_meta($user->ID,'_smc_phone',true), 'country'=>get_user_meta($user->ID,'_smc_country',true),
				'preferred_language'=>get_user_meta($user->ID,'_smc_language',true) ?: 'English',
				'calculated_age'=>(int)get_user_meta($user->ID,'_smc_age',true), 'account_type'=>get_user_meta($user->ID,'_smc_requested_role',true),
				'bio'=>get_user_meta($user->ID,'_smc_bio',true), 'created_at'=>$now, 'updated_at'=>$now,
			) );
			$identity=get_user_meta($user->ID,'_smc_identity_cipher',true);
			if($identity&&!$wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}smc_identity_records WHERE user_id=%d",$user->ID)))$wpdb->insert($wpdb->prefix.'smc_identity_records',array('user_id'=>$user->ID,'document_type'=>get_user_meta($user->ID,'_smc_id_type',true)?:'national_id','document_number_enc'=>'legacy:'.$identity,'name_match'=>'approved'===get_user_meta($user->ID,'_smc_status',true)?1:0,'created_at'=>$now,'updated_at'=>$now));
			$legacy_docs=get_user_meta($user->ID,'_smc_private_documents',true);
			foreach((array)$legacy_docs as$key=>$doc){if(empty($doc['file']))continue;$wpdb->replace($wpdb->prefix.'smc_identity_documents',array('user_id'=>$user->ID,'document_key'=>sanitize_key($key),'label'=>sanitize_text_field($doc['label']??$key),'stored_name'=>sanitize_file_name($doc['file']),'original_name'=>sanitize_file_name($doc['original']??'legacy-document'),'mime_type'=>sanitize_mime_type($doc['mime']??'image/jpeg'),'file_size'=>0,'status'=>'legacy','created_at'=>$now));}
			if('sabri_doctor'===get_user_meta($user->ID,'_smc_requested_role',true)&&!$wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}smc_professional_credentials WHERE user_id=%d",$user->ID))){$wpdb->insert($wpdb->prefix.'smc_professional_credentials',array('user_id'=>$user->ID,'qualification'=>get_user_meta($user->ID,'_smc_qualification',true),'registration_number'=>get_user_meta($user->ID,'_smc_license',true),'license_number'=>get_user_meta($user->ID,'_smc_license',true),'experience_years'=>(int)get_user_meta($user->ID,'_smc_experience',true),'specialization'=>get_user_meta($user->ID,'_smc_specialization',true),'books_studied'=>get_user_meta($user->ID,'_smc_books',true),'fee'=>(float)get_user_meta($user->ID,'_smc_fee',true),'currency'=>get_user_meta($user->ID,'_smc_currency',true)?:'USD','languages'=>get_user_meta($user->ID,'_smc_language',true),'created_at'=>$now,'updated_at'=>$now));$clinic_name=get_user_meta($user->ID,'_smc_clinic_name',true);if($clinic_name)$wpdb->insert($wpdb->prefix.'smc_clinics',array('owner_user_id'=>$user->ID,'name'=>$clinic_name,'address'=>get_user_meta($user->ID,'_smc_clinic_address',true),'country'=>get_user_meta($user->ID,'_smc_country',true),'phone'=>get_user_meta($user->ID,'_smc_phone',true),'whatsapp'=>get_user_meta($user->ID,'_smc_phone',true),'hours'=>get_user_meta($user->ID,'_smc_hours',true),'timezone'=>get_user_meta($user->ID,'_smc_timezone',true),'status'=>'approved','created_at'=>$now,'updated_at'=>$now));}
			if ( 'approved' === get_user_meta( $user->ID, '_smc_status', true ) ) update_user_meta( $user->ID, '_smc_approval_version', 1 );
		}
	}

	private static function ensure_founder() {
		$existing=get_users(array('meta_key'=>'_smc_official_founder','meta_value'=>1,'number'=>1,'fields'=>'ids'));
		if($existing)return;
		$admins=get_users(array('role'=>'administrator','number'=>1,'orderby'=>'ID','order'=>'ASC'));
		if(!$admins)return;
		$founder=$admins[0]; $name='Dr. Allama Majid Hussain Sabri Muhaddith Murshid';
		update_user_meta($founder->ID,'_smc_official_founder',1); update_user_meta($founder->ID,'_smc_trusted_publisher',1); update_user_meta($founder->ID,'_smc_status','approved');
		wp_update_user(array('ID'=>$founder->ID,'display_name'=>$name));
		if(!smc_get_profile($founder->ID)){global$wpdb;$now=current_time('mysql',true);$wpdb->insert($wpdb->prefix.'smc_member_profiles',array('user_id'=>$founder->ID,'legal_name'=>$name,'username_public'=>$founder->user_login,'phone'=>get_user_meta($founder->ID,'_smc_phone',true),'country'=>get_user_meta($founder->ID,'_smc_country',true),'preferred_language'=>'English','account_type'=>'sabri_doctor','bio'=>'Founder of the Sabri Homeopathy System of Healing.','created_at'=>$now,'updated_at'=>$now));}
	}
}
