<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function smc_roles() {
	return array(
		'sabri_patient'    => 'Patient',
		'sabri_doctor'     => 'Homeopathic Doctor',
		'sabri_student'    => 'Homeopathy Student',
		'sabri_teacher'    => 'Teacher',
		'sabri_researcher' => 'Researcher',
		'sabri_pharmacy'   => 'Pharmacy',
		'sabri_clinic'     => 'Clinic or Institution',
		'sabri_publisher'  => 'Publisher',
		'sabri_member'     => 'General Reader',
	);
}

function smc_statuses() {
	return array(
		'draft' => 'Draft', 'email_pending' => 'Email Verification Pending',
		'phone_pending' => 'Mobile Verification Pending', '2fa_pending' => '2FA Setup Pending',
		'documents_incomplete' => 'Documents Incomplete', 'submitted' => 'Submitted',
		'under_review' => 'Under Review', 'more_information' => 'More Information Required',
		'resubmitted' => 'Resubmitted', 'approved' => 'Approved', 'verified' => 'Verified',
		'rejected' => 'Rejected', 'suspended' => 'Suspended', 'expired_document' => 'Expired Document',
		'appeal_review' => 'Appeal Under Review',
	);
}

function smc_verification_badges() {
	return array(
		'email' => 'Email Verified', 'mobile' => 'Mobile Verified', 'identity' => 'Identity Verified',
		'doctor' => 'Doctor Verified', 'clinic' => 'Clinic Verified', 'researcher' => 'Researcher Verified',
		'institution' => 'Institution Verified', 'publisher' => 'Publisher Verified',
		'trusted' => 'Trusted Contributor', 'reviewer' => 'Senior Medical Reviewer', 'founder' => 'Official Founder',
	);
}

function smc_knowledge_sections() {
	return array(
		'daily-writings' => 'Daily Writings', 'articles' => 'Articles', 'clinical-cases' => 'Clinical Cases',
		'research' => 'Research', 'materia-medica-notes' => 'Materia Medica Notes', 'homeopathy' => 'Homeopathy',
		'nutrition-science' => 'Nutrition Science', 'pathology' => 'Pathology and Disease Science',
		'preventive-health' => 'Preventive Health', 'islamic-spiritual-care' => 'Islamic Spiritual Care',
		'books' => 'Books', 'lectures' => 'Lectures', 'references' => 'References',
	);
}

function smc_page_url( $shortcode, $fallback ) {
	static $cache = array();
	if ( isset( $cache[ $shortcode ] ) ) return $cache[ $shortcode ];
	$pages = get_posts( array( 'post_type' => 'page', 'post_status' => 'publish', 'numberposts' => 100, 'suppress_filters' => false ) );
	foreach ( $pages as $page ) {
		if ( has_shortcode( $page->post_content, $shortcode ) ) return $cache[ $shortcode ] = get_permalink( $page );
	}
	return $cache[ $shortcode ] = home_url( $fallback );
}

function smc_current_has_shortcode( $shortcode ) {
	if ( ! is_singular() ) return false;
	$post = get_queried_object();
	return $post instanceof WP_Post && has_shortcode( $post->post_content, $shortcode );
}

function smc_is_membership_page() {
	foreach ( array( 'sabri_register', 'sabri_login', 'sabri_profile', 'sabri_knowledge_archive', 'sabri_security_center', 'sabri_verification_status' ) as $shortcode ) {
		if ( smc_current_has_shortcode( $shortcode ) ) return true;
	}
	return false;
}

function smc_is_system_request() {
	$uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
	$path = wp_parse_url( $uri, PHP_URL_PATH );
	$path = is_string( $path ) && '' !== $path ? $path : '/';
	$base = basename( $path );

	if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) return true;
	if ( preg_match( '#^/(wp-admin|wp-login\.php|wp-cron\.php|xmlrpc\.php|wp-json|wp-content|wp-includes)(/|$)#', $path ) ) return true;
	if ( preg_match( '/^create_autologin_[A-Za-z0-9]+\.php$/', $base ) ) return true;
	if ( in_array( $base, array( 'favicon.ico', 'robots.txt' ), true ) ) return true;

	return false;
}

function smc_notice( $message, $type = 'info' ) {
	return '<div class="smc-notice smc-notice--' . esc_attr( $type ) . '" role="alert">' . esc_html( $message ) . '</div>';
}

function smc_clean_phone( $value ) { return preg_replace( '/[^0-9+]/', '', (string) $value ); }

function smc_age_from_dob( $dob ) {
	$date = DateTime::createFromFormat( 'Y-m-d', (string) $dob );
	$errors = DateTime::getLastErrors();
	if ( ! $date || ( is_array( $errors ) && ( $errors['warning_count'] || $errors['error_count'] ) ) || $date->format( 'Y-m-d' ) !== $dob ) return false;
	$today = new DateTime( 'today' );
	if ( $date > $today ) return false;
	return (int) $date->diff( $today )->y;
}

function smc_get_profile( $user_id ) {
	global $wpdb;
	return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}smc_member_profiles WHERE user_id = %d", $user_id ), ARRAY_A );
}

function smc_profile_value( $user_id, $key, $default = '' ) {
	$profile = smc_get_profile( $user_id );
	if ( isset( $profile[ $key ] ) && '' !== $profile[ $key ] ) return $profile[ $key ];
	$legacy = get_user_meta( $user_id, '_smc_' . $key, true );
	return '' !== $legacy ? $legacy : $default;
}

function smc_is_founder( $user_id ) { return (bool) get_user_meta( $user_id, '_smc_official_founder', true ); }
function smc_is_trusted_publisher( $user_id ) { return smc_is_founder( $user_id ) || (bool) get_user_meta( $user_id, '_smc_trusted_publisher', true ); }

function smc_required_documents( $role ) {
	$required = array( 'identity_front' => 'Identity document front', 'identity_back' => 'Identity document back or secondary page', 'profile_photo' => 'Clear profile photograph' );
	if ( 'sabri_doctor' === $role ) {
		$required += array( 'degree' => 'Homeopathic degree', 'license' => 'Registration or current licence', 'clinic_photo' => 'Clinic photograph', 'visiting_card' => 'Visiting card' );
	}
	if ( 'sabri_clinic' === $role ) {
		$required += array( 'institution_registration' => 'Institution registration', 'institution_license' => 'Institution licence', 'clinic_photo' => 'Clinic photograph', 'authorization' => 'Representative authorization' );
	}
	return $required;
}

function smc_user_status( $user_id ) {
	$status = get_user_meta( $user_id, '_smc_status', true );
	return isset( smc_statuses()[ $status ] ) ? $status : 'draft';
}

function smc_mask( $value, $visible = 4 ) {
	$value = (string) $value;
	return strlen( $value ) <= $visible ? str_repeat( '•', strlen( $value ) ) : str_repeat( '•', max( 4, strlen( $value ) - $visible ) ) . substr( $value, -$visible );
}

function smc_policy_version() { return '2026-07-13'; }
