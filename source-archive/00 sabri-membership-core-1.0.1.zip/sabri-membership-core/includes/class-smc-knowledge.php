<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMC_Knowledge {
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_filter( 'wp_insert_post_data', array( __CLASS__, 'enforce_review' ), 20, 2 );
		add_action( 'save_post_sabri_knowledge', array( __CLASS__, 'validate_section' ), 20, 3 );
		add_shortcode( 'sabri_knowledge_archive', array( __CLASS__, 'archive' ) );
	}

	public static function register() {
		register_post_type( 'sabri_knowledge', array(
			'labels'=>array('name'=>'Knowledge Encyclopedia','singular_name'=>'Knowledge Entry','add_new_item'=>'Add Knowledge Entry','edit_item'=>'Edit Knowledge Entry'),
			'public'=>true,'show_in_rest'=>true,'has_archive'=>true,'rewrite'=>array('slug'=>'knowledge'),'menu_icon'=>'dashicons-welcome-learn-more',
			'supports'=>array('title','editor','author','thumbnail','excerpt','comments','revisions'),'capability_type'=>'post','map_meta_cap'=>true,
		) );
		register_taxonomy('sabri_knowledge_type','sabri_knowledge',array('labels'=>array('name'=>'Knowledge Sections'),'public'=>true,'show_in_rest'=>true,'hierarchical'=>true,'rewrite'=>array('slug'=>'knowledge-section')));
		foreach(array('sabri_topic'=>'Topics','sabri_disease'=>'Diseases','sabri_remedy'=>'Remedies','sabri_language'=>'Languages') as $taxonomy=>$label)register_taxonomy($taxonomy,'sabri_knowledge',array('labels'=>array('name'=>$label),'public'=>true,'show_in_rest'=>true,'hierarchical'=>true,'rewrite'=>array('slug'=>str_replace('sabri_','',$taxonomy))));
	}

	public static function enforce_review( $data, $postarr ) {
		if(!in_array(($data['post_type']??''),array('sabri_knowledge','post'),true))return $data;
		$user_id=(int)($postarr['post_author']??get_current_user_id()); $role=get_user_meta($user_id,'_smc_requested_role',true);
		if(!$role)return $data;
		if(!smc_is_founder($user_id)&&'sabri_doctor'!==$role&&'sabri_verified_doctor'!==$role){$data['post_status']='draft';return $data;}
		if(!smc_is_trusted_publisher($user_id)&&in_array($data['post_status'],array('publish','future'),true))$data['post_status']='pending';
		return $data;
	}

	public static function validate_section( $post_id, $post, $update ) {
		if(wp_is_post_revision($post_id)||wp_is_post_autosave($post_id))return;
		$terms=wp_get_post_terms($post_id,'sabri_knowledge_type',array('fields'=>'slugs'));
		$allowed=array_keys(smc_knowledge_sections());
		if(!$terms||array_diff($terms,$allowed)){remove_action('save_post_sabri_knowledge',array(__CLASS__,'validate_section'),20);wp_update_post(array('ID'=>$post_id,'post_status'=>'draft'));add_action('save_post_sabri_knowledge',array(__CLASS__,'validate_section'),20,3);update_post_meta($post_id,'_smc_moderation_note','Select one approved Sabri knowledge section before submission.');}
		update_post_meta($post_id,'_smc_policy_version',smc_policy_version());
	}

	public static function count( $author, $section='' ) {
		$args=array('post_type'=>'sabri_knowledge','post_status'=>'publish','author'=>absint($author),'fields'=>'ids','posts_per_page'=>1);
		if($section)$args['tax_query']=array(array('taxonomy'=>'sabri_knowledge_type','field'=>'slug','terms'=>$section));
		$q=new WP_Query($args);return(int)$q->found_posts;
	}

	public static function archive() {
		if(!is_user_logged_in())return smc_notice('Registration and secure sign in are required.','error');
		$search=sanitize_text_field(wp_unslash($_GET['knowledge_search']??'')); $section=sanitize_title(wp_unslash($_GET['knowledge_section']??'')); $author=absint($_GET['doctor']??0); $paged=max(1,absint($_GET['knowledge_page']??1));
		$args=array('post_type'=>'sabri_knowledge','post_status'=>'publish','posts_per_page'=>12,'paged'=>$paged,'s'=>$search); if($author)$args['author']=$author; if($section&&isset(smc_knowledge_sections()[$section]))$args['tax_query']=array(array('taxonomy'=>'sabri_knowledge_type','field'=>'slug','terms'=>$section));
		$q=new WP_Query($args); $options='<option value="">All knowledge sections</option>'; foreach(smc_knowledge_sections() as $slug=>$name)$options.='<option value="'.esc_attr($slug).'"'.selected($section,$slug,false).'>'.esc_html($name).'</option>';
		$doctor=$author?get_userdata($author):false; $out='<div class="smc-app smc-knowledge"><header class="smc-knowledge-hero"><p class="smc-eyebrow">SABRI KNOWLEDGE ENCYCLOPEDIA</p><h1>'.($doctor?esc_html($doctor->display_name).' — Knowledge Archive':'Organized Global Knowledge').'</h1><p>Every article, case, remedy note and research record remains permanently organized, connected and searchable.</p></header><form class="smc-knowledge-search" method="get"><input name="knowledge_search" value="'.esc_attr($search).'" placeholder="Search knowledge, disease, remedy or topic"><select name="knowledge_section">'.$options.'</select>'.($author?'<input type="hidden" name="doctor" value="'.esc_attr($author).'">':'').'<button>Search Encyclopedia</button></form><nav class="smc-pills"><a href="'.esc_url(remove_query_arg(array('knowledge_section','knowledge_page'))).'">All</a>';
		foreach(smc_knowledge_sections() as $slug=>$name)$out.='<a class="'.($section===$slug?'is-active':'').'" href="'.esc_url(add_query_arg(array('knowledge_section'=>$slug,'doctor'=>$author?:false))).'">'.esc_html($name).'</a>';
		$out.='</nav><div class="smc-knowledge-grid">';
		if($q->have_posts()){while($q->have_posts()){$q->the_post();$types=wp_get_post_terms(get_the_ID(),'sabri_knowledge_type',array('fields'=>'names'));$out.='<article class="smc-knowledge-card"><span>'.esc_html($types[0]??'Knowledge').'</span><h2><a href="'.esc_url(get_permalink()).'">'.esc_html(get_the_title()).'</a></h2><p>'.esc_html(wp_trim_words(get_the_excerpt(),28)).'</p><footer><b>'.esc_html(get_the_author()).'</b><time>'.esc_html(get_the_date()).'</time></footer></article>';}wp_reset_postdata();}else$out.='<div class="smc-empty"><b>SH</b><h2>This organized section is ready</h2><p>Approved knowledge entries will appear here.</p></div>';
		$out.='</div>';if($q->max_num_pages>1)$out.='<nav class="smc-pagination">'.paginate_links(array('total'=>$q->max_num_pages,'current'=>$paged,'format'=>'?knowledge_page=%#%')).'</nav>';
		return $out.'</div>';
	}
}
