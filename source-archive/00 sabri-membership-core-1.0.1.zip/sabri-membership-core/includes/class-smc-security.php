<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMC_Security {
	public static function init() {
		add_filter( 'template_include', array( __CLASS__, 'template' ), 99 );
		add_action( 'template_redirect', array( __CLASS__, 'frontend_gate' ), 1 );
		add_filter( 'rest_pre_dispatch', array( __CLASS__, 'protect_rest' ), 10, 3 );
		add_filter( 'authenticate', array( __CLASS__, 'block_wp_login_bypass' ), 99 );
		add_action( 'admin_post_smc_private_document', array( __CLASS__, 'serve_document' ) );
		add_action( 'wp_login', array( __CLASS__, 'record_login' ), 10, 2 );
		add_action( 'wp_logout', array( __CLASS__, 'record_logout' ) );
		add_filter( 'wp_privacy_personal_data_exporters', array( __CLASS__, 'privacy_exporter' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( __CLASS__, 'privacy_eraser' ) );
		add_action( 'deleted_user', array( __CLASS__, 'cleanup_user' ) );
	}

	public static function template( $template ) {
		return smc_is_membership_page() ? SMC_PATH . 'templates/membership.php' : $template;
	}

	public static function frontend_gate() {
		if ( is_user_logged_in() || is_admin() || wp_doing_ajax() || wp_doing_cron() ) return;
		if ( smc_is_system_request() ) return;
		if ( smc_current_has_shortcode( 'sabri_login' ) || smc_current_has_shortcode( 'sabri_register' ) ) return;
		if ( is_privacy_policy() || is_page( array( 'privacy-policy','terms','terms-and-conditions' ) ) ) return;
		$requested = home_url( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ?? '/' ) ) );
		nocache_headers();
		wp_safe_redirect( add_query_arg( 'redirect_to', $requested, smc_page_url( 'sabri_login', '/sabri-login/' ) ) );
		exit;
	}

	public static function protect_rest( $result, $server, $request ) {
		if ( is_user_logged_in() ) return $result;
		foreach ( array( '/wp/v2/users','/wp/v2/sabri_knowledge','/wp/v2/sabri_knowledge_type','/wp/v2/sabri_topic','/wp/v2/sabri_disease','/wp/v2/sabri_remedy','/wp/v2/sabri_language' ) as $prefix ) {
			if ( 0 === strpos( $request->get_route(), $prefix ) ) return new WP_Error( 'smc_login_required', 'Registration and secure sign-in are required.', array( 'status'=>401 ) );
		}
		return $result;
	}

	public static function block_wp_login_bypass( $user ) {
		if ( ! $user instanceof WP_User || ! get_user_meta( $user->ID, '_smc_requested_role', true ) ) return $user;
		if ( 'approved' !== smc_user_status( $user->ID ) && 'verified' !== smc_user_status( $user->ID ) ) return new WP_Error( 'smc_pending', 'This Sabri account is awaiting institutional approval.' );
		return new WP_Error( 'smc_secure_login', 'Use the secure Sabri sign-in page with your Google Authenticator code.' );
	}

	public static function key( $purpose = 'identity' ) {
		$master = defined( 'SMC_MASTER_KEY' ) && SMC_MASTER_KEY ? SMC_MASTER_KEY : AUTH_KEY . SECURE_AUTH_KEY . LOGGED_IN_KEY;
		return hash_hmac( 'sha256', $purpose, $master, true );
	}

	public static function encrypt( $plain, $purpose = 'identity' ) {
		if ( ! function_exists( 'openssl_encrypt' ) ) return new WP_Error( 'smc_crypto', 'Secure encryption is unavailable on this server.' );
		$iv = random_bytes( 12 ); $tag = '';
		$cipher = openssl_encrypt( (string) $plain, 'aes-256-gcm', self::key( $purpose ), OPENSSL_RAW_DATA, $iv, $tag );
		return false === $cipher ? new WP_Error( 'smc_crypto', 'Encryption failed.' ) : base64_encode( "SMC1" . $iv . $tag . $cipher );
	}

	public static function decrypt( $encoded, $purpose = 'identity' ) {
		$payload = base64_decode( (string) $encoded, true );
		if ( false === $payload || strlen( $payload ) < 32 || 'SMC1' !== substr( $payload, 0, 4 ) ) return false;
		$iv = substr( $payload, 4, 12 ); $tag = substr( $payload, 16, 16 ); $cipher = substr( $payload, 32 );
		return openssl_decrypt( $cipher, 'aes-256-gcm', self::key( $purpose ), OPENSSL_RAW_DATA, $iv, $tag );
	}

	private static function legacy_document_decrypt( $payload ) {
		if(strlen((string)$payload)<29||!function_exists('openssl_decrypt'))return false;
		$key=hash('sha256',AUTH_KEY.SECURE_AUTH_KEY.'sabri-private-documents',true);
		return openssl_decrypt(substr($payload,28),'aes-256-gcm',$key,OPENSSL_RAW_DATA,substr($payload,0,12),substr($payload,12,16));
	}

	public static function private_dir() {
		$dir = WP_CONTENT_DIR . '/sabri-private-documents';
		if ( ! is_dir( $dir ) ) wp_mkdir_p( $dir );
		if ( is_dir( $dir ) ) {
			if ( ! file_exists( $dir . '/index.php' ) ) file_put_contents( $dir . '/index.php', "<?php\nhttp_response_code(404);\nexit;\n", LOCK_EX );
			if ( ! file_exists( $dir . '/.htaccess' ) ) file_put_contents( $dir . '/.htaccess', "Deny from all\nRequire all denied\n", LOCK_EX );
			if ( ! file_exists( $dir . '/web.config' ) ) file_put_contents( $dir . '/web.config', '<configuration><system.webServer><authorization><deny users="*" /></authorization></system.webServer></configuration>', LOCK_EX );
		}
		return $dir;
	}

	public static function store_document( $field, $label, $user_id, $key ) {
		if ( empty( $_FILES[ $field ] ) || ! is_array( $_FILES[ $field ] ) ) return new WP_Error( 'smc_upload', $label . ' is required.' );
		$file = $_FILES[ $field ];
		if ( UPLOAD_ERR_OK !== (int) $file['error'] || ! is_uploaded_file( $file['tmp_name'] ) ) return new WP_Error( 'smc_upload', $label . ' could not be uploaded.' );
		if ( (int) $file['size'] < 1024 || (int) $file['size'] > 8 * MB_IN_BYTES ) return new WP_Error( 'smc_upload', $label . ' must be a clear image smaller than 8 MB.' );
		$allowed = array( 'jpg|jpeg'=>'image/jpeg', 'png'=>'image/png', 'webp'=>'image/webp', 'pdf'=>'application/pdf' );
		$checked = wp_check_filetype_and_ext( $file['tmp_name'], sanitize_file_name( $file['name'] ), $allowed );
		$mime = $checked['type'] ?? '';
		if ( ! in_array( $mime, array_values( $allowed ), true ) ) return new WP_Error( 'smc_upload', $label . ' must be JPG, PNG, WebP, or PDF.' );
		if ( 'application/pdf' === $mime && in_array( $key, array( 'identity_front','identity_back','profile_photo','clinic_photo','visiting_card' ), true ) ) return new WP_Error( 'smc_upload', $label . ' must be a clear JPG, PNG, or WebP image.' );
		if ( 0 === strpos( $mime, 'image/' ) ) {
			$info = @getimagesize( $file['tmp_name'] );
			if ( ! is_array( $info ) || $info[0] < 500 || $info[1] < 300 ) return new WP_Error( 'smc_upload', $label . ' is too small or is not a valid image.' );
		}
		$bytes = file_get_contents( $file['tmp_name'] );
		$encrypted = false === $bytes ? false : self::encrypt( $bytes, 'private-document' );
		if ( ! $encrypted || is_wp_error( $encrypted ) ) return new WP_Error( 'smc_upload', $label . ' could not be encrypted.' );
		$stored = wp_generate_uuid4() . '.smcdoc';
		if ( false === file_put_contents( trailingslashit( self::private_dir() ) . $stored, $encrypted, LOCK_EX ) ) return new WP_Error( 'smc_upload', $label . ' could not be stored securely.' );
		global $wpdb;
		$previous=$wpdb->get_row($wpdb->prepare("SELECT stored_name FROM {$wpdb->prefix}smc_identity_documents WHERE user_id=%d AND document_key=%s",$user_id,$key),ARRAY_A);
		$wpdb->replace( $wpdb->prefix . 'smc_identity_documents', array(
			'user_id'=>$user_id, 'document_key'=>$key, 'label'=>$label, 'stored_name'=>$stored,
			'original_name'=>sanitize_file_name($file['name']), 'mime_type'=>$mime, 'file_size'=>(int)$file['size'], 'status'=>'submitted', 'created_at'=>current_time('mysql',true),
		) );
		if($previous&&!empty($previous['stored_name'])){$old=trailingslashit(self::private_dir()).basename($previous['stored_name']);if(file_exists($old))unlink($old);}
		return true;
	}

	public static function document_url( $document_id ) {
		return wp_nonce_url( admin_url( 'admin-post.php?action=smc_private_document&document_id=' . absint( $document_id ) ), 'smc_document_' . absint( $document_id ) );
	}

	public static function serve_document() {
		if ( ! current_user_can( 'smc_view_private_documents' ) && ! current_user_can( 'manage_options' ) ) wp_die( 'Not authorized.', 403 );
		$id = absint( $_GET['document_id'] ?? 0 );
		check_admin_referer( 'smc_document_' . $id );
		global $wpdb;
		$doc = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}smc_identity_documents WHERE id=%d", $id ), ARRAY_A );
		if ( ! $doc ) wp_die( 'Document not found.', 404 );
		$path = trailingslashit( self::private_dir() ) . basename( $doc['stored_name'] );
		$encoded = file_exists( $path ) ? file_get_contents( $path ) : false;
		$plain = false === $encoded ? false : self::decrypt( $encoded, 'private-document' );
		if(false===$plain&&false!==$encoded)$plain=self::legacy_document_decrypt($encoded);
		if ( false === $plain ) wp_die( 'The encrypted document could not be opened.', 500 );
		self::audit( 'private_document_viewed', (int)$doc['user_id'], 'identity_document', $id );
		nocache_headers();
		header( 'X-Content-Type-Options: nosniff' ); header( 'X-Frame-Options: SAMEORIGIN' ); header( 'Content-Security-Policy: default-src \'none\'; img-src \'self\' data:; style-src \'unsafe-inline\'' );
		header( 'Content-Type: ' . sanitize_mime_type( $doc['mime_type'] ) );
		header( 'Content-Disposition: inline; filename="' . sanitize_file_name( $doc['original_name'] ) . '"' );
		echo $plain; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		exit;
	}

	public static function base32_secret( $length = 32 ) {
		$alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $out = '';
		for ( $i=0; $i<$length; $i++ ) $out .= $alphabet[random_int(0,31)];
		return $out;
	}

	private static function base32_decode( $secret ) {
		$alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; $secret=strtoupper(preg_replace('/[^A-Z2-7]/i','',$secret)); $bits='';
		foreach(str_split($secret) as $char) $bits .= str_pad(decbin(strpos($alphabet,$char)),5,'0',STR_PAD_LEFT);
		$out=''; for($i=0;$i+8<=strlen($bits);$i+=8) $out .= chr(bindec(substr($bits,$i,8))); return $out;
	}

	public static function totp( $secret, $slice = null ) {
		if ( null === $slice ) $slice = floor( time()/30 );
		$counter=pack('N*',0).pack('N*',$slice); $hash=hash_hmac('sha1',$counter,self::base32_decode($secret),true);
		$offset=ord(substr($hash,-1))&0x0f; $value=unpack('N',substr($hash,$offset,4))[1]&0x7fffffff;
		return str_pad((string)($value%1000000),6,'0',STR_PAD_LEFT);
	}

	public static function verify_totp( $secret, $code ) {
		$code=preg_replace('/\D/','',(string)$code); if(strlen($code)!==6||!$secret)return false;
		foreach(array(-1,0,1) as $w) if(hash_equals(self::totp($secret,floor(time()/30)+$w),$code))return true; return false;
	}

	public static function recovery_codes( $user_id, $count = 8 ) {
		$plain=array(); $hashes=array();
		for($i=0;$i<$count;$i++){ $code=strtoupper(wp_generate_password(10,false,false)); $plain[]=$code; $hashes[]=wp_hash_password($code); }
		update_user_meta($user_id,'_smc_recovery_codes',$hashes); return $plain;
	}

	public static function consume_recovery_code( $user_id, $code ) {
		$hashes=(array)get_user_meta($user_id,'_smc_recovery_codes',true);
		foreach($hashes as $i=>$hash){ if(wp_check_password(strtoupper(trim($code)),$hash)){ unset($hashes[$i]); update_user_meta($user_id,'_smc_recovery_codes',array_values($hashes)); self::audit('recovery_code_used',$user_id); return true; } }
		return false;
	}

	public static function rate_limited( $bucket, $limit = 7, $seconds = 900 ) {
		$key='smc_rate_'.hash('sha256',$bucket.'|'.($_SERVER['REMOTE_ADDR']??'')); $state=get_transient($key);
		if(!is_array($state))$state=array('count'=>0); $state['count']++;
		set_transient($key,$state,$seconds); return $state['count']>$limit;
	}

	public static function audit( $action, $subject_user_id=0, $object_type='', $object_id=0, $details=array() ) {
		global $wpdb; $actor=get_current_user_id();
		$wpdb->insert($wpdb->prefix.'smc_audit_log',array('actor_id'=>$actor,'subject_user_id'=>$subject_user_id,'action'=>sanitize_key($action),'object_type'=>sanitize_key($object_type),'object_id'=>$object_id,'details'=>wp_json_encode($details),'created_at'=>current_time('mysql',true)));
		$wpdb->insert($wpdb->prefix.'smc_security_events',array('user_id'=>$subject_user_id,'event_type'=>sanitize_key($action),'ip_hash'=>hash('sha256',($_SERVER['REMOTE_ADDR']??'').'|'.AUTH_SALT),'user_agent_hash'=>hash('sha256',($_SERVER['HTTP_USER_AGENT']??'').'|'.AUTH_SALT),'details'=>wp_json_encode($details),'created_at'=>current_time('mysql',true)));
	}

	public static function record_login( $login, $user ) { if(get_user_meta($user->ID,'_smc_requested_role',true))self::audit('login_success',$user->ID); }
	public static function record_logout() { $id=get_current_user_id(); if($id)self::audit('logout',$id); }

	public static function privacy_exporter( $exporters ) {
		$exporters['sabri-membership']=array('exporter_friendly_name'=>'Sabri Membership Data','callback'=>array(__CLASS__,'export_personal_data'));
		return $exporters;
	}

	public static function export_personal_data( $email, $page=1 ) {
		$user=get_user_by('email',$email); if(!$user)return array('data'=>array(),'done'=>true); global$wpdb;
		$profile=smc_get_profile($user->ID); $credential=$wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}smc_professional_credentials WHERE user_id=%d",$user->ID),ARRAY_A);
		$data=array(); foreach((array)$profile as$key=>$value)if(!in_array($key,array('id','date_of_birth_enc'),true))$data[]=array('name'=>ucwords(str_replace('_',' ',$key)),'value'=>(string)$value);
		foreach((array)$credential as$key=>$value)if('id'!==$key)$data[]=array('name'=>'Professional: '.ucwords(str_replace('_',' ',$key)),'value'=>(string)$value);
		return array('data'=>array(array('group_id'=>'sabri-membership','group_label'=>'Sabri Membership','item_id'=>'sabri-member-'.$user->ID,'data'=>$data)),'done'=>true);
	}

	public static function privacy_eraser( $erasers ) {
		$erasers['sabri-membership']=array('eraser_friendly_name'=>'Sabri Membership Data','callback'=>array(__CLASS__,'erase_personal_data'));
		return $erasers;
	}

	public static function erase_personal_data( $email, $page=1 ) {
		$user=get_user_by('email',$email); if(!$user)return array('items_removed'=>false,'items_retained'=>false,'messages'=>array(),'done'=>true);
		self::cleanup_user($user->ID); self::audit('privacy_data_erased',$user->ID);
		return array('items_removed'=>true,'items_retained'=>false,'messages'=>array(),'done'=>true);
	}

	public static function cleanup_user( $user_id ) {
		global$wpdb;$docs=$wpdb->get_results($wpdb->prepare("SELECT stored_name FROM {$wpdb->prefix}smc_identity_documents WHERE user_id=%d",$user_id),ARRAY_A);
		foreach($docs as$doc){$path=trailingslashit(self::private_dir()).basename($doc['stored_name']);if(file_exists($path))unlink($path);}
		foreach(array('smc_member_profiles','smc_identity_records','smc_identity_documents','smc_verification_requests','smc_verification_events','smc_professional_credentials','smc_consents','smc_subscriptions')as$table)$wpdb->delete($wpdb->prefix.$table,array('user_id'=>$user_id));
		$wpdb->delete($wpdb->prefix.'smc_clinics',array('owner_user_id'=>$user_id));
	}
}
