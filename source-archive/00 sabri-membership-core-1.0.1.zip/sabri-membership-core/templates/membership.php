<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?><!doctype html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo( 'charset' ); ?>"><meta name="viewport" content="width=device-width,initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class( 'smc-standalone' ); ?>><?php wp_body_open(); ?>
<header class="smc-topbar"><a class="smc-topbar-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>"><b>SH</b><span><strong>Sabri Homeopathy</strong><small>Global Knowledge &amp; Clinic Network</small></span></a><nav><a href="<?php echo esc_url( home_url( '/' ) ); ?>">News</a><?php if ( is_user_logged_in() ) : ?><a href="<?php echo esc_url( smc_page_url( 'sabri_knowledge_archive', '/sabri-knowledge-archive/' ) ); ?>">Encyclopedia</a><a href="<?php echo esc_url( smc_page_url( 'sabri_profile', '/sabri-profile/' ) ); ?>">Profile</a><a class="smc-nav-signout" href="<?php echo esc_url( wp_logout_url( smc_page_url( 'sabri_login', '/sabri-login/' ) ) ); ?>">Log out</a><?php else : ?><a href="<?php echo esc_url( smc_page_url( 'sabri_login', '/sabri-login/' ) ); ?>">Sign in</a><?php endif; ?></nav></header>
<div class="smc-content"><?php while ( have_posts() ) { the_post(); the_content(); } ?></div>
<?php wp_footer(); ?></body></html>
